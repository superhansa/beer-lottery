var arr = new Array();
$('.next-ball').on('click', function (){
  var random = Math.floor(Math.random()*146); //Enter the amount of sold tickets + 1 here!
  console.log('tiss' + random);
  if( arr.indexOf(random) == -1){
    arr.push(random);
    $('.super').replaceWith('<li class="super">'+ random + '</li>');
    $('.lottery').prepend('<li class="lottery-ball">' + random + '</li>');
    
  } else {
    alert(' Beep bop, I am your master and I can´t let some get beer twice on the same number ('+random +'). Draw again, you slave!');
  }
  console.log(arr);
  if ( $('.lottery').children().length > 400 ) {
    $('.next-ball').hide();
    $('.play-again').show();
  }

  
});
$('.play-again').on('click', function(){
  $('.lottery').children().remove();
  arr = [];
  $('.next-ball').show();
  $('.play-again').hide();
});